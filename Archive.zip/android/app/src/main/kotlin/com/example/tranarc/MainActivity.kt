package com.example.tranarc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
